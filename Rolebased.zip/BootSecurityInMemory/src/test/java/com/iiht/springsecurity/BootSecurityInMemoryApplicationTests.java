package com.iiht.springsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityInMemoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
